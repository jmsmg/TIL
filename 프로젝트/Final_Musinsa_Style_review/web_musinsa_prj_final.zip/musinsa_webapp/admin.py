from django.contrib import admin
from .models import ImageUploadModel
from django.utils.safestring import mark_safe
# Register your models here.


class ImageUploadAdmin(admin.ModelAdmin):

    readonly_fields = ('document_preview',)

    fieldsets = [

    ("File", {'fields' : ['description']}),
    ("Detail", {'fields' : ['document',]}),
    # ("Date", {'fields' : ['uploaded_at']}),
    ('document_preview', {'fields' : ['document_preview']}),
    ('point_get', {'fields' : ['point_get']}),

    ]


    def document_preview(self, obj):
        return obj.document_preview
    #
    #
    document_preview.short_description = 'document_preview'
    document_preview.allow_tags = True

    list_display = ( 'description', 'document','uploaded_at','point_get','document_preview') # list_display 변수명은 고정
    list_filter = ['uploaded_at']
    search_fields = ['description']

admin.site.register(ImageUploadModel, ImageUploadAdmin)
