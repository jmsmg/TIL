from django.conf import settings
from tensorflow.keras import models
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import numpy as np
import cv2


def predict_fn(path):
  img = cv2.imread(path)
  img = img*(1./255)
  img = cv2.resize(img,(300,300))
  img = img.astype('float32')
  img = cv2.cvtColor(img,cv2.COLOR_RGB2BGR)
  img = img.reshape(1,300,300,3)
  result = round(settings.MODEL.predict(img)[0][0]*100,2)
  return result
