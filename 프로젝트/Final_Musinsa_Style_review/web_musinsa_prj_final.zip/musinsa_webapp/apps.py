from django.apps import AppConfig


class MusinsaWebappConfig(AppConfig):
    name = 'musinsa_webapp'
